const token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJTSVBEX0FVVEhfU0VSVklDRSIsInN1YiI6IjI3MTg1LjcwIiwiZXhwIjoxNzcwNDA0Mjc5LCJpYXQiOjE3NzAxODgyNzksInRhaHVuIjoyMDI1LCJpZF91c2VyIjoyNzE4NSwiaWRfZGFlcmFoIjo3MCwia29kZV9wcm92aW5zaSI6IjMzIiwia29kZV9kZG4iOiIzMy43NiIsImlkX3NrcGQiOjQ3NSwiaWRfcm9sZSI6MTAsImlkX3BlZ2F3YWkiOjY1ODk0OCwic3ViX2RvbWFpbl9kYWVyYWgiOiJ0ZWdhbCJ9.BEXjxyVOS_itLcxQ4IPI1omCoF6xZnNvC6wpmSLwQg0"; 



function getCookie(name) {
  const value = `; ${document.cookie}`;
  const parts = value.split(`; ${name}=`);
  if (parts.length === 2) return parts.pop().split(';').shift();
  return null; 
}

const namaBulan = [
  "",
  "Januari",
  "Februari",
  "Maret",
  "April",
  "Mei",
  "Juni",
  "Juli",
  "Agustus",
  "September",
  "Oktober",
  "November",
  "Desember"
];

const parentElement = document.querySelector('.nav-tools.flex.items-center');
const newDiv = document.createElement('div');
const button = document.createElement('button');
button.textContent = 'Sinkronkan Simlaba';
button.className = 'btn undefined btn inline-flex justify-center bg-danger-500 text-white';
button.setAttribute('type', 'button');
button.setAttribute('data-bs-toggle', 'tooltip');
button.setAttribute('data-bs-placement', 'top');
button.setAttribute('title', 'Sinkronkan Realisasi Keuangan ke Simlaba');
button.innerHTML = '<img src="https://cdn-icons-png.flaticon.com/128/2512/2512713.png" width="32" height="32">';
newDiv.appendChild(button);
parentElement.prepend(newDiv);    

button.addEventListener('click', () => {

  const modal = document.createElement('div');
  modal.classList.add('modal-backdrop');
  modal.style.position = 'fixed';
  modal.style.top = '0';
  modal.style.left = '0';
  modal.style.width = '100%';
  modal.style.height = '100%';
  modal.style.background = 'rgba(0, 0, 0, 0.5)';
  modal.style.display = 'flex';
  modal.style.justifyContent = 'center';
  modal.style.alignItems = 'center';
  modal.style.zIndex = '1000';

  
  const box = document.createElement('div');
  box.classList.add('modal-box');
  box.style.background = '#fff';
  box.style.padding = '20px';
  box.style.borderRadius = '10px';
  box.style.minWidth = '300px';
  box.style.maxWidth = '90%';
  box.style.boxShadow = '0 0 10px rgba(0,0,0,0.3)';
  box.style.animation = 'fadeIn 0.06s ease';

  
  box.innerHTML = `
    <h3>Sinkronisasi SIPD & Simlaba</h3>
    <p>----------------------------</p>
      <form id="syncSimlabaForm">
        <label for="syncbulan">Pilih Bulan:</label>
        <select name="syncbulan" id="syncbulan" required>
          <option value="1">Januari</option>
          <option value="2">Februari</option>
          <option value="3">Maret</option>
          <option value="4">April</option>
          <option value="5">Mei</option>
          <option value="6">Juni</option>
          <option value="7">Juli</option>
          <option value="8">Agustus</option>
          <option value="9">September</option>
          <option value="10">Oktober</option>
          <option value="11">November</option>
          <option value="12">Desember</option>
        </select>
        <p>----------------------------</p>
        <br/>
        <button id="closeModalBtn" class="btn inline-flex justify-center bg-danger-500 text-white">Tutup</button> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button type="submit" class="btn inline-flex justify-center bg-success-500 text-white">Proses</button> 
      </form>
      <div id="syncLoaderAnim" style="display:none;"><img src="https://cdn.dribbble.com/userupload/24354714/file/original-0252e0e6dca0c37238eff2620cf51653.gif" style="width:260px;height:210px">  </div>
      <div id="syncNotif" style="display:none;">AAAAAAA</div>
  `;

  
  modal.appendChild(box);
  document.body.appendChild(modal);

  
  document.getElementById('closeModalBtn').addEventListener('click', () => {
    document.body.removeChild(modal);
  });

 
  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      document.body.removeChild(modal);
    }
  });

  document.getElementById('syncSimlabaForm').addEventListener('submit', function(event) {
    event.preventDefault(); 

    document.getElementById("syncLoaderAnim").style.display = "block";
    document.getElementById("syncSimlabaForm").style.display = "none";
  
    const formData = new FormData(this);
    const tbulan = document.getElementById('syncbulan').value;
    
    const xtoken = getCookie('X-SIPD-PU-TK');
    const xurl = `https://service.sipd.kemendagri.go.id/pengeluaran/strict/lpj/adm-fungs/0?type=SKPD&id_pegawai=0&bulan=${tbulan}`;
    
  
    const xhr = new XMLHttpRequest();
    xhr.open("GET", xurl, true);
    xhr.setRequestHeader("accept", "application/json");
    xhr.setRequestHeader("authorization", `Bearer ${xtoken}`);
    
    xhr.onload = function () {
      if (xhr.status >= 200 && xhr.status < 300) {
        const obj = JSON.parse(xhr.responseText);
        console.log("Response:",obj);
        const ptahun = obj.tahun;
        const remote_url = `https://monevrkpd.tegalkota.go.id/emonev${ptahun}/api/sipd/updaerealisasikeuangan`;
        
                fetch(remote_url, {
                  method: 'POST',
                  headers: {
                    "Content-Type": 'application/json',
                    "Authorization": `Bearer ${token}`,
                  },
                  body: JSON.stringify({
                    'jumlah_sd_saat_ini':obj.pembukuan1[0].jumlah_sd_saat_ini,
                    'tahun' : ptahun,
                    'bulan': tbulan,
                    'kode_pd':obj.kode_skpd,
                    'xdata': obj.pembukuan2,
                    'chrversion' : '1.4'
                  })
                })
                .then(response => {
                  if (!response.ok) {
                    throw new Error('Network response was not ok');
                  }
                  return response.json(); 
                })
                .then(data => {
                  namaBulanIni = namaBulan[tbulan];
                  console.log('Success:', data);
                  document.getElementById("syncLoaderAnim").style.display = "none";
                  document.getElementById("syncSimlabaForm").style.display = "none";
                  document.getElementById("syncNotif").style.display = "block";
                  document.getElementById("syncNotif").innerHTML = `Data realisasi keuangan bulan <b> ${namaBulanIni} ${ptahun} </b>berhasil diunduh ke Simlaba :<b> Rp.  ${data.total}</b>`;
                })
                .catch(error => {
                  console.error('Error:', error);
                  console.log('Success:', data);
                  document.getElementById("syncLoaderAnim").style.display = "none";
                  document.getElementById("syncSimlabaForm").style.display = "none";
                  document.getElementById("syncNotif").style.display = "block";
                  document.getElementById("syncNotif").innerHTML = "ERROR BOS";
                });
      } else {
        console.error(`HTTP error ${xhr.status}: ${xhr.statusText}`);
        document.getElementById("syncLoaderAnim").style.display = "none";
        document.getElementById("syncSimlabaForm").style.display = "none";
        document.getElementById("syncNotif").style.display = "block";
        document.getElementById("syncNotif").innerHTML = "ERROR BOS";
      }
    };


    xhr.onerror = function () {
      console.error("Network error occurred");
      document.getElementById("syncLoaderAnim").style.display = "none";
                  document.getElementById("syncSimlabaForm").style.display = "none";
                  document.getElementById("syncNotif").style.display = "block";
                  document.getElementById("syncNotif").innerHTML = "ERROR BOS";
    };
    xhr.send();


  });

});
