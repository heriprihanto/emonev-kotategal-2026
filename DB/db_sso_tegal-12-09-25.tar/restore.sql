--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.15 (Ubuntu 14.15-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.15 (Ubuntu 14.15-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE db_sso_tegal;
--
-- Name: db_sso_tegal; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE db_sso_tegal WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE db_sso_tegal OWNER TO postgres;

\connect db_sso_tegal

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: armor(bytea); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.armor(bytea) RETURNS text
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pg_armor';


ALTER FUNCTION public.armor(bytea) OWNER TO monevrkpd;

--
-- Name: armor(bytea, text[], text[]); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.armor(bytea, text[], text[]) RETURNS text
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pg_armor';


ALTER FUNCTION public.armor(bytea, text[], text[]) OWNER TO monevrkpd;

--
-- Name: crypt(text, text); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.crypt(text, text) RETURNS text
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pg_crypt';


ALTER FUNCTION public.crypt(text, text) OWNER TO monevrkpd;

--
-- Name: dearmor(text); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.dearmor(text) RETURNS bytea
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pg_dearmor';


ALTER FUNCTION public.dearmor(text) OWNER TO monevrkpd;

--
-- Name: decrypt(bytea, bytea, text); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.decrypt(bytea, bytea, text) RETURNS bytea
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pg_decrypt';


ALTER FUNCTION public.decrypt(bytea, bytea, text) OWNER TO monevrkpd;

--
-- Name: decrypt_iv(bytea, bytea, bytea, text); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.decrypt_iv(bytea, bytea, bytea, text) RETURNS bytea
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pg_decrypt_iv';


ALTER FUNCTION public.decrypt_iv(bytea, bytea, bytea, text) OWNER TO monevrkpd;

--
-- Name: digest(bytea, text); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.digest(bytea, text) RETURNS bytea
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pg_digest';


ALTER FUNCTION public.digest(bytea, text) OWNER TO monevrkpd;

--
-- Name: digest(text, text); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.digest(text, text) RETURNS bytea
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pg_digest';


ALTER FUNCTION public.digest(text, text) OWNER TO monevrkpd;

--
-- Name: encode_passwd(text, text); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.encode_passwd(pusername text, ppassword text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
  s_enc text;
  s_salt text;
BEGIN
 SELECT salt FROM users WHERE username = pusername into s_salt;  
 RETURN encode(digest(CONCAT(s_salt, ppassword)::text,'sha256'),'hex');
END;
$$;


ALTER FUNCTION public.encode_passwd(pusername text, ppassword text) OWNER TO monevrkpd;

--
-- Name: encrypt(bytea, bytea, text); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.encrypt(bytea, bytea, text) RETURNS bytea
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pg_encrypt';


ALTER FUNCTION public.encrypt(bytea, bytea, text) OWNER TO monevrkpd;

--
-- Name: encrypt_iv(bytea, bytea, bytea, text); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.encrypt_iv(bytea, bytea, bytea, text) RETURNS bytea
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pg_encrypt_iv';


ALTER FUNCTION public.encrypt_iv(bytea, bytea, bytea, text) OWNER TO monevrkpd;

--
-- Name: gen_random_bytes(integer); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.gen_random_bytes(integer) RETURNS bytea
    LANGUAGE c STRICT
    AS '$libdir/pgcrypto', 'pg_random_bytes';


ALTER FUNCTION public.gen_random_bytes(integer) OWNER TO monevrkpd;

--
-- Name: gen_salt(text); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.gen_salt(text) RETURNS text
    LANGUAGE c STRICT
    AS '$libdir/pgcrypto', 'pg_gen_salt';


ALTER FUNCTION public.gen_salt(text) OWNER TO monevrkpd;

--
-- Name: gen_salt(text, integer); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.gen_salt(text, integer) RETURNS text
    LANGUAGE c STRICT
    AS '$libdir/pgcrypto', 'pg_gen_salt_rounds';


ALTER FUNCTION public.gen_salt(text, integer) OWNER TO monevrkpd;

--
-- Name: hmac(bytea, bytea, text); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.hmac(bytea, bytea, text) RETURNS bytea
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pg_hmac';


ALTER FUNCTION public.hmac(bytea, bytea, text) OWNER TO monevrkpd;

--
-- Name: hmac(text, text, text); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.hmac(text, text, text) RETURNS bytea
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pg_hmac';


ALTER FUNCTION public.hmac(text, text, text) OWNER TO monevrkpd;

--
-- Name: login_user(integer, text, text); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.login_user(ptahun integer, pusername text, ppassword text) RETURNS TABLE(id integer, email text, username text, password text, display_name text, display_name_changed date, reset_hash text, last_login timestamp without time zone, last_ip text, created_on timestamp without time zone, deleted integer, reset_by integer, banned integer, ban_message text, timezone text, language text, active integer, activate_hash text, force_password_reset integer, salt text, id_instansi integer, no_telp text, role_id text, app_id text, role text, app_name text, tahun integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
 
RETURN QUERY 
    SELECT x.id,
    x.email,
    x.username,
    x.password,
    x.display_name,
    x.display_name_changed,
    x.reset_hash,
    x.last_login,
    x.last_ip,
    x.created_on,
    x.deleted,
    x.reset_by,
    x.banned,
    x.ban_message,
    x.timezone,
    x.language,
    x.active,
    x.activate_hash,
    x.force_password_reset,
    x.salt,
    x.id_instansi,
    x.no_telp,
    string_agg(x.role_id::text, ','::text) AS role_id,
    string_agg(x.app_id::text, ','::text) AS app_id,
    string_agg(x.role, ','::text) AS role,
    string_agg(x.app_name, ','::text) AS app_name,
    ptahun as tahun
FROM (
    SELECT users.id,
            users.email,
            users.username,
            users.password,
            users.display_name,
            users.display_name_changed,
            users.reset_hash,
            users.last_login,
            users.last_ip,
            users.created_on,
            users.deleted,
            users.reset_by,
            users.banned,
            users.ban_message,
            users.timezone,
            users.language,
            users.active,
            users.activate_hash,
            users.force_password_reset,
            users.salt,
            users.id_instansi,
            users.no_telp,
            user_role.role_id,
            app_role.app_id,
            app_role.role,
            apps.app_name
    FROM user_role
             JOIN app_role ON user_role.role_id = app_role.id
             JOIN users ON user_role.user_id = users.id
             JOIN apps ON app_role.app_id = apps.id
    ) x
GROUP BY x.id, x.email, x.username, x.password, x.display_name,
    x.display_name_changed, x.reset_hash, x.last_login, x.last_ip, x.created_on, x.deleted, x.reset_by, x.banned, x.ban_message, x.timezone, x.language, x.active, x.activate_hash, x.force_password_reset, x.salt, x.id_instansi, x.no_telp;

END;
$$;


ALTER FUNCTION public.login_user(ptahun integer, pusername text, ppassword text) OWNER TO monevrkpd;

--
-- Name: pgp_key_id(bytea); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.pgp_key_id(bytea) RETURNS text
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pgp_key_id_w';


ALTER FUNCTION public.pgp_key_id(bytea) OWNER TO monevrkpd;

--
-- Name: pgp_pub_decrypt(bytea, bytea); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.pgp_pub_decrypt(bytea, bytea) RETURNS text
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pgp_pub_decrypt_text';


ALTER FUNCTION public.pgp_pub_decrypt(bytea, bytea) OWNER TO monevrkpd;

--
-- Name: pgp_pub_decrypt(bytea, bytea, text); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.pgp_pub_decrypt(bytea, bytea, text) RETURNS text
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pgp_pub_decrypt_text';


ALTER FUNCTION public.pgp_pub_decrypt(bytea, bytea, text) OWNER TO monevrkpd;

--
-- Name: pgp_pub_decrypt(bytea, bytea, text, text); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.pgp_pub_decrypt(bytea, bytea, text, text) RETURNS text
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pgp_pub_decrypt_text';


ALTER FUNCTION public.pgp_pub_decrypt(bytea, bytea, text, text) OWNER TO monevrkpd;

--
-- Name: pgp_pub_decrypt_bytea(bytea, bytea); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea) RETURNS bytea
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pgp_pub_decrypt_bytea';


ALTER FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea) OWNER TO monevrkpd;

--
-- Name: pgp_pub_decrypt_bytea(bytea, bytea, text); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea, text) RETURNS bytea
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pgp_pub_decrypt_bytea';


ALTER FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea, text) OWNER TO monevrkpd;

--
-- Name: pgp_pub_decrypt_bytea(bytea, bytea, text, text); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea, text, text) RETURNS bytea
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pgp_pub_decrypt_bytea';


ALTER FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea, text, text) OWNER TO monevrkpd;

--
-- Name: pgp_pub_encrypt(text, bytea); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.pgp_pub_encrypt(text, bytea) RETURNS bytea
    LANGUAGE c STRICT
    AS '$libdir/pgcrypto', 'pgp_pub_encrypt_text';


ALTER FUNCTION public.pgp_pub_encrypt(text, bytea) OWNER TO monevrkpd;

--
-- Name: pgp_pub_encrypt(text, bytea, text); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.pgp_pub_encrypt(text, bytea, text) RETURNS bytea
    LANGUAGE c STRICT
    AS '$libdir/pgcrypto', 'pgp_pub_encrypt_text';


ALTER FUNCTION public.pgp_pub_encrypt(text, bytea, text) OWNER TO monevrkpd;

--
-- Name: pgp_pub_encrypt_bytea(bytea, bytea); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.pgp_pub_encrypt_bytea(bytea, bytea) RETURNS bytea
    LANGUAGE c STRICT
    AS '$libdir/pgcrypto', 'pgp_pub_encrypt_bytea';


ALTER FUNCTION public.pgp_pub_encrypt_bytea(bytea, bytea) OWNER TO monevrkpd;

--
-- Name: pgp_pub_encrypt_bytea(bytea, bytea, text); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.pgp_pub_encrypt_bytea(bytea, bytea, text) RETURNS bytea
    LANGUAGE c STRICT
    AS '$libdir/pgcrypto', 'pgp_pub_encrypt_bytea';


ALTER FUNCTION public.pgp_pub_encrypt_bytea(bytea, bytea, text) OWNER TO monevrkpd;

--
-- Name: pgp_sym_decrypt(bytea, text); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.pgp_sym_decrypt(bytea, text) RETURNS text
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pgp_sym_decrypt_text';


ALTER FUNCTION public.pgp_sym_decrypt(bytea, text) OWNER TO monevrkpd;

--
-- Name: pgp_sym_decrypt(bytea, text, text); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.pgp_sym_decrypt(bytea, text, text) RETURNS text
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pgp_sym_decrypt_text';


ALTER FUNCTION public.pgp_sym_decrypt(bytea, text, text) OWNER TO monevrkpd;

--
-- Name: pgp_sym_decrypt_bytea(bytea, text); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.pgp_sym_decrypt_bytea(bytea, text) RETURNS bytea
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pgp_sym_decrypt_bytea';


ALTER FUNCTION public.pgp_sym_decrypt_bytea(bytea, text) OWNER TO monevrkpd;

--
-- Name: pgp_sym_decrypt_bytea(bytea, text, text); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.pgp_sym_decrypt_bytea(bytea, text, text) RETURNS bytea
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/pgcrypto', 'pgp_sym_decrypt_bytea';


ALTER FUNCTION public.pgp_sym_decrypt_bytea(bytea, text, text) OWNER TO monevrkpd;

--
-- Name: pgp_sym_encrypt(text, text); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.pgp_sym_encrypt(text, text) RETURNS bytea
    LANGUAGE c STRICT
    AS '$libdir/pgcrypto', 'pgp_sym_encrypt_text';


ALTER FUNCTION public.pgp_sym_encrypt(text, text) OWNER TO monevrkpd;

--
-- Name: pgp_sym_encrypt(text, text, text); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.pgp_sym_encrypt(text, text, text) RETURNS bytea
    LANGUAGE c STRICT
    AS '$libdir/pgcrypto', 'pgp_sym_encrypt_text';


ALTER FUNCTION public.pgp_sym_encrypt(text, text, text) OWNER TO monevrkpd;

--
-- Name: pgp_sym_encrypt_bytea(bytea, text); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.pgp_sym_encrypt_bytea(bytea, text) RETURNS bytea
    LANGUAGE c STRICT
    AS '$libdir/pgcrypto', 'pgp_sym_encrypt_bytea';


ALTER FUNCTION public.pgp_sym_encrypt_bytea(bytea, text) OWNER TO monevrkpd;

--
-- Name: pgp_sym_encrypt_bytea(bytea, text, text); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.pgp_sym_encrypt_bytea(bytea, text, text) RETURNS bytea
    LANGUAGE c STRICT
    AS '$libdir/pgcrypto', 'pgp_sym_encrypt_bytea';


ALTER FUNCTION public.pgp_sym_encrypt_bytea(bytea, text, text) OWNER TO monevrkpd;

--
-- Name: ring_text(character varying); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.ring_text(stext character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
DECLARE
  nval VARCHAR;
BEGIN
  	SELECT lower(trim(REPLACE(regexp_replace(regexp_replace(stext, '\\W', '', 'g'),'[^[:alpha:]\\s]','','g'),' ','')))::varchar INTO nval;
  	RETURN nval;
    
END;
$$;


ALTER FUNCTION public.ring_text(stext character varying) OWNER TO monevrkpd;

--
-- Name: updatepasswd(character varying, character varying); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.updatepasswd(pusername character varying, ppasswd character varying, OUT poutput numeric) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
BEGIN
  UPDATE users set "password"=(SELECT (ENCODE(DIGEST(concat(salt,ppasswd),'sha256'),'hex')) FROM users WHERE username=pusername) WHERE username=pusername;
  SELECT 1::numeric INTO poutput;
END;
$$;


ALTER FUNCTION public.updatepasswd(pusername character varying, ppasswd character varying, OUT poutput numeric) OWNER TO monevrkpd;

--
-- Name: uuid_generate_v1(); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.uuid_generate_v1() RETURNS uuid
    LANGUAGE c STRICT
    AS '$libdir/uuid-ossp', 'uuid_generate_v1';


ALTER FUNCTION public.uuid_generate_v1() OWNER TO monevrkpd;

--
-- Name: uuid_generate_v1mc(); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.uuid_generate_v1mc() RETURNS uuid
    LANGUAGE c STRICT
    AS '$libdir/uuid-ossp', 'uuid_generate_v1mc';


ALTER FUNCTION public.uuid_generate_v1mc() OWNER TO monevrkpd;

--
-- Name: uuid_generate_v3(uuid, text); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.uuid_generate_v3(namespace uuid, name text) RETURNS uuid
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/uuid-ossp', 'uuid_generate_v3';


ALTER FUNCTION public.uuid_generate_v3(namespace uuid, name text) OWNER TO monevrkpd;

--
-- Name: uuid_generate_v4(); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.uuid_generate_v4() RETURNS uuid
    LANGUAGE c STRICT
    AS '$libdir/uuid-ossp', 'uuid_generate_v4';


ALTER FUNCTION public.uuid_generate_v4() OWNER TO monevrkpd;

--
-- Name: uuid_generate_v5(uuid, text); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.uuid_generate_v5(namespace uuid, name text) RETURNS uuid
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/uuid-ossp', 'uuid_generate_v5';


ALTER FUNCTION public.uuid_generate_v5(namespace uuid, name text) OWNER TO monevrkpd;

--
-- Name: uuid_nil(); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.uuid_nil() RETURNS uuid
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/uuid-ossp', 'uuid_nil';


ALTER FUNCTION public.uuid_nil() OWNER TO monevrkpd;

--
-- Name: uuid_ns_dns(); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.uuid_ns_dns() RETURNS uuid
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/uuid-ossp', 'uuid_ns_dns';


ALTER FUNCTION public.uuid_ns_dns() OWNER TO monevrkpd;

--
-- Name: uuid_ns_oid(); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.uuid_ns_oid() RETURNS uuid
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/uuid-ossp', 'uuid_ns_oid';


ALTER FUNCTION public.uuid_ns_oid() OWNER TO monevrkpd;

--
-- Name: uuid_ns_url(); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.uuid_ns_url() RETURNS uuid
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/uuid-ossp', 'uuid_ns_url';


ALTER FUNCTION public.uuid_ns_url() OWNER TO monevrkpd;

--
-- Name: uuid_ns_x500(); Type: FUNCTION; Schema: public; Owner: monevrkpd
--

CREATE FUNCTION public.uuid_ns_x500() RETURNS uuid
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/uuid-ossp', 'uuid_ns_x500';


ALTER FUNCTION public.uuid_ns_x500() OWNER TO monevrkpd;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: app_role; Type: TABLE; Schema: public; Owner: monevrkpd
--

CREATE TABLE public.app_role (
    id integer NOT NULL,
    app_id integer,
    role_id_app integer,
    role text
);


ALTER TABLE public.app_role OWNER TO monevrkpd;

--
-- Name: app_role_id_seq; Type: SEQUENCE; Schema: public; Owner: monevrkpd
--

CREATE SEQUENCE public.app_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.app_role_id_seq OWNER TO monevrkpd;

--
-- Name: app_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: monevrkpd
--

ALTER SEQUENCE public.app_role_id_seq OWNED BY public.app_role.id;


--
-- Name: apps; Type: TABLE; Schema: public; Owner: monevrkpd
--

CREATE TABLE public.apps (
    id integer NOT NULL,
    app_name text NOT NULL,
    notes text,
    uuid text,
    name character varying,
    url character varying
);


ALTER TABLE public.apps OWNER TO monevrkpd;

--
-- Name: apps_id_seq; Type: SEQUENCE; Schema: public; Owner: monevrkpd
--

CREATE SEQUENCE public.apps_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.apps_id_seq OWNER TO monevrkpd;

--
-- Name: apps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: monevrkpd
--

ALTER SEQUENCE public.apps_id_seq OWNED BY public.apps.id;


--
-- Name: inbox; Type: TABLE; Schema: public; Owner: monevrkpd
--

CREATE TABLE public.inbox (
    id integer NOT NULL,
    msg character varying,
    phone character varying,
    tgl timestamp without time zone
);


ALTER TABLE public.inbox OWNER TO monevrkpd;

--
-- Name: inbox_id_seq; Type: SEQUENCE; Schema: public; Owner: monevrkpd
--

CREATE SEQUENCE public.inbox_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.inbox_id_seq OWNER TO monevrkpd;

--
-- Name: inbox_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: monevrkpd
--

ALTER SEQUENCE public.inbox_id_seq OWNED BY public.inbox.id;


--
-- Name: ref_sub_pd; Type: TABLE; Schema: public; Owner: monevrkpd
--

CREATE TABLE public.ref_sub_pd (
    id_sub_pd integer NOT NULL,
    kd_urusan integer,
    kd_bidang integer,
    kd_unit integer,
    kd_sub integer,
    kode_sub_pd character varying,
    nm_sub_pd character varying(255),
    nm_singkat character varying(150),
    nm_sub_unit_simpeg character varying(255),
    group_opd integer DEFAULT 0,
    id_parent integer DEFAULT 0,
    jenis_unit integer DEFAULT 1,
    nm_pimpinan character varying,
    jbt_pimpinan character varying,
    pangkat_pimpinan character varying,
    nip_pimpinan character varying,
    nama_jabatan character varying,
    id_sub_pd_mapping integer,
    alamat character varying,
    telp character varying,
    fax character varying,
    website character varying,
    email character varying,
    header_kop character varying,
    id_pd integer
);


ALTER TABLE public.ref_sub_pd OWNER TO monevrkpd;

--
-- Name: ref_sub_unit; Type: TABLE; Schema: public; Owner: monevrkpd
--

CREATE TABLE public.ref_sub_unit (
    id integer,
    kd_urusan integer,
    kd_bidang integer,
    kd_unit integer,
    kd_sub integer,
    nm_sub_unit character varying,
    nm_singkat character varying,
    nm_sub_unit_simpeg character varying,
    group_opd integer,
    id_parent integer
);


ALTER TABLE public.ref_sub_unit OWNER TO monevrkpd;

--
-- Name: ref_sub_unit_2; Type: TABLE; Schema: public; Owner: monevrkpd
--

CREATE TABLE public.ref_sub_unit_2 (
    id integer,
    kd_urusan integer,
    kd_bidang integer,
    kd_unit integer,
    kd_sub integer,
    nm_sub_unit character varying,
    nm_singkat character varying,
    nm_sub_unit_simpeg character varying,
    group_opd integer,
    id_parent integer
);


ALTER TABLE public.ref_sub_unit_2 OWNER TO monevrkpd;

--
-- Name: user_log; Type: TABLE; Schema: public; Owner: monevrkpd
--

CREATE TABLE public.user_log (
    id integer NOT NULL,
    tgl date,
    created_at timestamp with time zone DEFAULT now(),
    username character varying,
    nama character varying
);


ALTER TABLE public.user_log OWNER TO monevrkpd;

--
-- Name: user_log_id_seq; Type: SEQUENCE; Schema: public; Owner: monevrkpd
--

CREATE SEQUENCE public.user_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_log_id_seq OWNER TO monevrkpd;

--
-- Name: user_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: monevrkpd
--

ALTER SEQUENCE public.user_log_id_seq OWNED BY public.user_log.id;


--
-- Name: user_role; Type: TABLE; Schema: public; Owner: monevrkpd
--

CREATE TABLE public.user_role (
    id integer NOT NULL,
    user_id integer,
    role_id integer,
    aktif integer DEFAULT 1
);


ALTER TABLE public.user_role OWNER TO monevrkpd;

--
-- Name: user_role_id_seq; Type: SEQUENCE; Schema: public; Owner: monevrkpd
--

CREATE SEQUENCE public.user_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_role_id_seq OWNER TO monevrkpd;

--
-- Name: user_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: monevrkpd
--

ALTER SEQUENCE public.user_role_id_seq OWNED BY public.user_role.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: monevrkpd
--

CREATE TABLE public.users (
    id integer NOT NULL,
    role_id integer,
    email text,
    username text,
    password text,
    display_name text,
    display_name_changed date,
    reset_hash text,
    last_login timestamp without time zone,
    last_ip text,
    created_on timestamp without time zone,
    deleted integer,
    reset_by integer,
    banned integer,
    ban_message text,
    timezone text,
    language text,
    active integer,
    activate_hash text,
    force_password_reset integer,
    salt text,
    id_instansi integer,
    no_telp text,
    opd text,
    opds integer[],
    apps character varying[]
);


ALTER TABLE public.users OWNER TO monevrkpd;

--
-- Name: users01; Type: TABLE; Schema: public; Owner: monevrkpd
--

CREATE TABLE public.users01 (
    id integer NOT NULL,
    role_id integer,
    email text,
    username text,
    password text,
    display_name text,
    display_name_changed date,
    reset_hash text,
    last_login timestamp without time zone,
    last_ip text,
    created_on timestamp without time zone,
    deleted integer,
    reset_by integer,
    banned integer,
    ban_message text,
    timezone text,
    language text,
    active integer,
    activate_hash text,
    force_password_reset integer,
    salt text,
    id_instansi integer,
    no_telp text,
    opd text,
    opds integer[],
    apps character varying[]
);


ALTER TABLE public.users01 OWNER TO monevrkpd;

--
-- Name: users01_id_seq; Type: SEQUENCE; Schema: public; Owner: monevrkpd
--

CREATE SEQUENCE public.users01_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users01_id_seq OWNER TO monevrkpd;

--
-- Name: users01_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: monevrkpd
--

ALTER SEQUENCE public.users01_id_seq OWNED BY public.users01.id;


--
-- Name: users_backup; Type: TABLE; Schema: public; Owner: monevrkpd
--

CREATE TABLE public.users_backup (
    id integer NOT NULL,
    role_id integer,
    email text,
    username text,
    password text,
    display_name text,
    display_name_changed date,
    reset_hash text,
    last_login timestamp without time zone,
    last_ip text,
    created_on timestamp without time zone,
    deleted integer,
    reset_by integer,
    banned integer,
    ban_message text,
    timezone text,
    language text,
    active integer,
    activate_hash text,
    force_password_reset integer,
    salt text,
    id_instansi integer,
    no_telp text,
    opd text
);


ALTER TABLE public.users_backup OWNER TO monevrkpd;

--
-- Name: users_backup_id_seq; Type: SEQUENCE; Schema: public; Owner: monevrkpd
--

CREATE SEQUENCE public.users_backup_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_backup_id_seq OWNER TO monevrkpd;

--
-- Name: users_backup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: monevrkpd
--

ALTER SEQUENCE public.users_backup_id_seq OWNED BY public.users_backup.id;


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: monevrkpd
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO monevrkpd;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: monevrkpd
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: usr_op; Type: TABLE; Schema: public; Owner: monevrkpd
--

CREATE TABLE public.usr_op (
    id integer,
    username text,
    display_name text,
    nm_sub_unit_simpeg text,
    simpeg text
);


ALTER TABLE public.usr_op OWNER TO monevrkpd;

--
-- Name: view_user_opd; Type: VIEW; Schema: public; Owner: monevrkpd
--

CREATE VIEW public.view_user_opd AS
 SELECT users.username,
    users.display_name,
    users.no_telp,
    ref_sub_unit.nm_sub_unit
   FROM (public.users
     JOIN public.ref_sub_unit ON ((users.id_instansi = ref_sub_unit.id)));


ALTER TABLE public.view_user_opd OWNER TO monevrkpd;

--
-- Name: view_users; Type: VIEW; Schema: public; Owner: monevrkpd
--

CREATE VIEW public.view_users AS
 SELECT x.id,
    x.email,
    x.username,
    x.password,
    x.display_name,
    x.display_name_changed,
    x.reset_hash,
    x.last_login,
    x.last_ip,
    x.created_on,
    x.deleted,
    x.reset_by,
    x.banned,
    x.ban_message,
    x.timezone,
    x.language,
    x.active,
    x.activate_hash,
    x.force_password_reset,
    x.salt,
    x.id_instansi,
    x.no_telp,
    string_agg((x.role_id)::text, ','::text) AS role_id,
    string_agg((x.app_id)::text, ','::text) AS app_id,
    string_agg(x.role, ','::text) AS role,
    string_agg((x.role_id_app)::text, ','::text) AS role_id_app,
    string_agg(x.app_name, ','::text) AS app_name
   FROM ( SELECT users.id,
            users.email,
            users.username,
            users.password,
            users.display_name,
            users.display_name_changed,
            users.reset_hash,
            users.last_login,
            users.last_ip,
            users.created_on,
            users.deleted,
            users.reset_by,
            users.banned,
            users.ban_message,
            users.timezone,
            users.language,
            users.active,
            users.activate_hash,
            users.force_password_reset,
            users.salt,
            users.id_instansi,
            users.no_telp,
            user_role.role_id,
            app_role.app_id,
            app_role.role,
            app_role.role_id_app,
            apps.app_name
           FROM (((public.user_role
             JOIN public.app_role ON ((user_role.role_id = app_role.id)))
             JOIN public.users ON ((user_role.user_id = users.id)))
             JOIN public.apps ON ((app_role.app_id = apps.id)))) x
  GROUP BY x.id, x.email, x.username, x.password, x.display_name, x.display_name_changed, x.reset_hash, x.last_login, x.last_ip, x.created_on, x.deleted, x.reset_by, x.banned, x.ban_message, x.timezone, x.language, x.active, x.activate_hash, x.force_password_reset, x.salt, x.id_instansi, x.no_telp;


ALTER TABLE public.view_users OWNER TO monevrkpd;

--
-- Name: view_users2; Type: VIEW; Schema: public; Owner: monevrkpd
--

CREATE VIEW public.view_users2 AS
 SELECT u.id,
    u.role_id,
    u.email,
    u.username,
    u.password,
    u.display_name,
    u.display_name_changed,
    u.reset_hash,
    u.last_login,
    u.last_ip,
    u.created_on,
    u.deleted,
    u.reset_by,
    u.banned,
    u.ban_message,
    u.timezone,
    u.language,
    u.active,
    u.activate_hash,
    u.force_password_reset,
    u.salt,
    u.id_instansi,
    u.no_telp,
    u.opd,
    pd.nm_sub_pd,
    pd.nm_sub_unit_simpeg,
    pd.id_sub_pd,
    pd.kd_urusan,
    pd.kd_bidang,
    pd.kd_unit,
    pd.kd_sub,
    pd.kode_sub_pd,
    pd.id_pd,
    r.role_id AS role_id1,
    r.aktif,
    ar.app_id,
    ar.role_id_app,
    ar.role,
    a.app_name
   FROM ((((public.users u
     JOIN public.user_role r ON ((u.id = r.user_id)))
     JOIN public.app_role ar ON ((r.role_id = ar.id)))
     JOIN public.apps a ON ((ar.app_id = a.id)))
     LEFT JOIN public.ref_sub_pd pd ON ((u.id_instansi = pd.id_sub_pd_mapping)));


ALTER TABLE public.view_users2 OWNER TO monevrkpd;

--
-- Name: view_users3; Type: VIEW; Schema: public; Owner: monevrkpd
--

CREATE VIEW public.view_users3 AS
 SELECT u.id,
    u.role_id,
    u.email,
    u.username,
    u.password,
    u.display_name,
    u.display_name_changed,
    u.reset_hash,
    u.last_login,
    u.last_ip,
    u.created_on,
    u.deleted,
    u.reset_by,
    u.banned,
    u.ban_message,
    u.timezone,
    u.language,
    u.active,
    u.activate_hash,
    u.force_password_reset,
    u.salt,
    u.id_instansi,
    u.no_telp,
    u.opd,
    r.role_id AS role_id1,
    r.aktif,
    ar.app_id,
    ar.role_id_app,
    ar.role,
    a.app_name,
    a.notes,
    a.name,
    un.nm_sub_unit_simpeg,
    un.nm_sub_unit,
    un.nm_singkat,
    pd.id_sub_pd,
    pd.kd_urusan,
    pd.kd_bidang,
    pd.kd_unit,
    pd.kd_sub,
    pd.group_opd,
    pd.id_parent
   FROM (((((public.users u
     JOIN public.user_role r ON ((u.id = r.user_id)))
     JOIN public.app_role ar ON ((r.role_id = ar.id)))
     JOIN public.apps a ON ((ar.app_id = a.id)))
     LEFT JOIN public.ref_sub_unit un ON ((u.id_instansi = un.id)))
     LEFT JOIN public.ref_sub_pd pd ON ((un.id = pd.id_sub_pd_mapping)));


ALTER TABLE public.view_users3 OWNER TO monevrkpd;

--
-- Name: app_role id; Type: DEFAULT; Schema: public; Owner: monevrkpd
--

ALTER TABLE ONLY public.app_role ALTER COLUMN id SET DEFAULT nextval('public.app_role_id_seq'::regclass);


--
-- Name: apps id; Type: DEFAULT; Schema: public; Owner: monevrkpd
--

ALTER TABLE ONLY public.apps ALTER COLUMN id SET DEFAULT nextval('public.apps_id_seq'::regclass);


--
-- Name: inbox id; Type: DEFAULT; Schema: public; Owner: monevrkpd
--

ALTER TABLE ONLY public.inbox ALTER COLUMN id SET DEFAULT nextval('public.inbox_id_seq'::regclass);


--
-- Name: user_log id; Type: DEFAULT; Schema: public; Owner: monevrkpd
--

ALTER TABLE ONLY public.user_log ALTER COLUMN id SET DEFAULT nextval('public.user_log_id_seq'::regclass);


--
-- Name: user_role id; Type: DEFAULT; Schema: public; Owner: monevrkpd
--

ALTER TABLE ONLY public.user_role ALTER COLUMN id SET DEFAULT nextval('public.user_role_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: monevrkpd
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: users01 id; Type: DEFAULT; Schema: public; Owner: monevrkpd
--

ALTER TABLE ONLY public.users01 ALTER COLUMN id SET DEFAULT nextval('public.users01_id_seq'::regclass);


--
-- Name: users_backup id; Type: DEFAULT; Schema: public; Owner: monevrkpd
--

ALTER TABLE ONLY public.users_backup ALTER COLUMN id SET DEFAULT nextval('public.users_backup_id_seq'::regclass);


--
-- Data for Name: app_role; Type: TABLE DATA; Schema: public; Owner: monevrkpd
--

COPY public.app_role (id, app_id, role_id_app, role) FROM stdin;
\.
COPY public.app_role (id, app_id, role_id_app, role) FROM '$$PATH$$/3476.dat';

--
-- Data for Name: apps; Type: TABLE DATA; Schema: public; Owner: monevrkpd
--

COPY public.apps (id, app_name, notes, uuid, name, url) FROM stdin;
\.
COPY public.apps (id, app_name, notes, uuid, name, url) FROM '$$PATH$$/3478.dat';

--
-- Data for Name: inbox; Type: TABLE DATA; Schema: public; Owner: monevrkpd
--

COPY public.inbox (id, msg, phone, tgl) FROM stdin;
\.
COPY public.inbox (id, msg, phone, tgl) FROM '$$PATH$$/3480.dat';

--
-- Data for Name: ref_sub_pd; Type: TABLE DATA; Schema: public; Owner: monevrkpd
--

COPY public.ref_sub_pd (id_sub_pd, kd_urusan, kd_bidang, kd_unit, kd_sub, kode_sub_pd, nm_sub_pd, nm_singkat, nm_sub_unit_simpeg, group_opd, id_parent, jenis_unit, nm_pimpinan, jbt_pimpinan, pangkat_pimpinan, nip_pimpinan, nama_jabatan, id_sub_pd_mapping, alamat, telp, fax, website, email, header_kop, id_pd) FROM stdin;
\.
COPY public.ref_sub_pd (id_sub_pd, kd_urusan, kd_bidang, kd_unit, kd_sub, kode_sub_pd, nm_sub_pd, nm_singkat, nm_sub_unit_simpeg, group_opd, id_parent, jenis_unit, nm_pimpinan, jbt_pimpinan, pangkat_pimpinan, nip_pimpinan, nama_jabatan, id_sub_pd_mapping, alamat, telp, fax, website, email, header_kop, id_pd) FROM '$$PATH$$/3482.dat';

--
-- Data for Name: ref_sub_unit; Type: TABLE DATA; Schema: public; Owner: monevrkpd
--

COPY public.ref_sub_unit (id, kd_urusan, kd_bidang, kd_unit, kd_sub, nm_sub_unit, nm_singkat, nm_sub_unit_simpeg, group_opd, id_parent) FROM stdin;
\.
COPY public.ref_sub_unit (id, kd_urusan, kd_bidang, kd_unit, kd_sub, nm_sub_unit, nm_singkat, nm_sub_unit_simpeg, group_opd, id_parent) FROM '$$PATH$$/3483.dat';

--
-- Data for Name: ref_sub_unit_2; Type: TABLE DATA; Schema: public; Owner: monevrkpd
--

COPY public.ref_sub_unit_2 (id, kd_urusan, kd_bidang, kd_unit, kd_sub, nm_sub_unit, nm_singkat, nm_sub_unit_simpeg, group_opd, id_parent) FROM stdin;
\.
COPY public.ref_sub_unit_2 (id, kd_urusan, kd_bidang, kd_unit, kd_sub, nm_sub_unit, nm_singkat, nm_sub_unit_simpeg, group_opd, id_parent) FROM '$$PATH$$/3484.dat';

--
-- Data for Name: user_log; Type: TABLE DATA; Schema: public; Owner: monevrkpd
--

COPY public.user_log (id, tgl, created_at, username, nama) FROM stdin;
\.
COPY public.user_log (id, tgl, created_at, username, nama) FROM '$$PATH$$/3485.dat';

--
-- Data for Name: user_role; Type: TABLE DATA; Schema: public; Owner: monevrkpd
--

COPY public.user_role (id, user_id, role_id, aktif) FROM stdin;
\.
COPY public.user_role (id, user_id, role_id, aktif) FROM '$$PATH$$/3487.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: monevrkpd
--

COPY public.users (id, role_id, email, username, password, display_name, display_name_changed, reset_hash, last_login, last_ip, created_on, deleted, reset_by, banned, ban_message, timezone, language, active, activate_hash, force_password_reset, salt, id_instansi, no_telp, opd, opds, apps) FROM stdin;
\.
COPY public.users (id, role_id, email, username, password, display_name, display_name_changed, reset_hash, last_login, last_ip, created_on, deleted, reset_by, banned, ban_message, timezone, language, active, activate_hash, force_password_reset, salt, id_instansi, no_telp, opd, opds, apps) FROM '$$PATH$$/3489.dat';

--
-- Data for Name: users01; Type: TABLE DATA; Schema: public; Owner: monevrkpd
--

COPY public.users01 (id, role_id, email, username, password, display_name, display_name_changed, reset_hash, last_login, last_ip, created_on, deleted, reset_by, banned, ban_message, timezone, language, active, activate_hash, force_password_reset, salt, id_instansi, no_telp, opd, opds, apps) FROM stdin;
\.
COPY public.users01 (id, role_id, email, username, password, display_name, display_name_changed, reset_hash, last_login, last_ip, created_on, deleted, reset_by, banned, ban_message, timezone, language, active, activate_hash, force_password_reset, salt, id_instansi, no_telp, opd, opds, apps) FROM '$$PATH$$/3495.dat';

--
-- Data for Name: users_backup; Type: TABLE DATA; Schema: public; Owner: monevrkpd
--

COPY public.users_backup (id, role_id, email, username, password, display_name, display_name_changed, reset_hash, last_login, last_ip, created_on, deleted, reset_by, banned, ban_message, timezone, language, active, activate_hash, force_password_reset, salt, id_instansi, no_telp, opd) FROM stdin;
\.
COPY public.users_backup (id, role_id, email, username, password, display_name, display_name_changed, reset_hash, last_login, last_ip, created_on, deleted, reset_by, banned, ban_message, timezone, language, active, activate_hash, force_password_reset, salt, id_instansi, no_telp, opd) FROM '$$PATH$$/3490.dat';

--
-- Data for Name: usr_op; Type: TABLE DATA; Schema: public; Owner: monevrkpd
--

COPY public.usr_op (id, username, display_name, nm_sub_unit_simpeg, simpeg) FROM stdin;
\.
COPY public.usr_op (id, username, display_name, nm_sub_unit_simpeg, simpeg) FROM '$$PATH$$/3493.dat';

--
-- Name: app_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: monevrkpd
--

SELECT pg_catalog.setval('public.app_role_id_seq', 28, true);


--
-- Name: apps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: monevrkpd
--

SELECT pg_catalog.setval('public.apps_id_seq', 6, true);


--
-- Name: inbox_id_seq; Type: SEQUENCE SET; Schema: public; Owner: monevrkpd
--

SELECT pg_catalog.setval('public.inbox_id_seq', 15, true);


--
-- Name: user_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: monevrkpd
--

SELECT pg_catalog.setval('public.user_log_id_seq', 1, false);


--
-- Name: user_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: monevrkpd
--

SELECT pg_catalog.setval('public.user_role_id_seq', 697, true);


--
-- Name: users01_id_seq; Type: SEQUENCE SET; Schema: public; Owner: monevrkpd
--

SELECT pg_catalog.setval('public.users01_id_seq', 1, false);


--
-- Name: users_backup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: monevrkpd
--

SELECT pg_catalog.setval('public.users_backup_id_seq', 1616, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: monevrkpd
--

SELECT pg_catalog.setval('public.users_id_seq', 2301, true);


--
-- Name: app_role app_role_pkey; Type: CONSTRAINT; Schema: public; Owner: monevrkpd
--

ALTER TABLE ONLY public.app_role
    ADD CONSTRAINT app_role_pkey PRIMARY KEY (id);


--
-- Name: apps apps_app_name_key; Type: CONSTRAINT; Schema: public; Owner: monevrkpd
--

ALTER TABLE ONLY public.apps
    ADD CONSTRAINT apps_app_name_key UNIQUE (app_name);


--
-- Name: apps apps_pkey; Type: CONSTRAINT; Schema: public; Owner: monevrkpd
--

ALTER TABLE ONLY public.apps
    ADD CONSTRAINT apps_pkey PRIMARY KEY (id);


--
-- Name: inbox inbox_pkey; Type: CONSTRAINT; Schema: public; Owner: monevrkpd
--

ALTER TABLE ONLY public.inbox
    ADD CONSTRAINT inbox_pkey PRIMARY KEY (id);


--
-- Name: ref_sub_pd ref_sub_pd_pkey; Type: CONSTRAINT; Schema: public; Owner: monevrkpd
--

ALTER TABLE ONLY public.ref_sub_pd
    ADD CONSTRAINT ref_sub_pd_pkey PRIMARY KEY (id_sub_pd);


--
-- Name: user_role user_role_pkey; Type: CONSTRAINT; Schema: public; Owner: monevrkpd
--

ALTER TABLE ONLY public.user_role
    ADD CONSTRAINT user_role_pkey PRIMARY KEY (id);


--
-- Name: users_backup users_backup_email_key; Type: CONSTRAINT; Schema: public; Owner: monevrkpd
--

ALTER TABLE ONLY public.users_backup
    ADD CONSTRAINT users_backup_email_key UNIQUE (email);


--
-- Name: users_backup users_backup_pkey; Type: CONSTRAINT; Schema: public; Owner: monevrkpd
--

ALTER TABLE ONLY public.users_backup
    ADD CONSTRAINT users_backup_pkey PRIMARY KEY (id);


--
-- Name: users_backup users_backup_username_key; Type: CONSTRAINT; Schema: public; Owner: monevrkpd
--

ALTER TABLE ONLY public.users_backup
    ADD CONSTRAINT users_backup_username_key UNIQUE (username);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: monevrkpd
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users01 users_email_key01; Type: CONSTRAINT; Schema: public; Owner: monevrkpd
--

ALTER TABLE ONLY public.users01
    ADD CONSTRAINT users_email_key01 UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: monevrkpd
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users01 users_pkey01; Type: CONSTRAINT; Schema: public; Owner: monevrkpd
--

ALTER TABLE ONLY public.users01
    ADD CONSTRAINT users_pkey01 PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: monevrkpd
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: users01 users_username_key01; Type: CONSTRAINT; Schema: public; Owner: monevrkpd
--

ALTER TABLE ONLY public.users01
    ADD CONSTRAINT users_username_key01 UNIQUE (username);


--
-- Name: user_role_idx; Type: INDEX; Schema: public; Owner: monevrkpd
--

CREATE UNIQUE INDEX user_role_idx ON public.user_role USING btree (user_id, role_id);


--
-- Name: app_role app_role_fk; Type: FK CONSTRAINT; Schema: public; Owner: monevrkpd
--

ALTER TABLE ONLY public.app_role
    ADD CONSTRAINT app_role_fk FOREIGN KEY (app_id) REFERENCES public.apps(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: user_role user_role_fk; Type: FK CONSTRAINT; Schema: public; Owner: monevrkpd
--

ALTER TABLE ONLY public.user_role
    ADD CONSTRAINT user_role_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_role user_role_fk1; Type: FK CONSTRAINT; Schema: public; Owner: monevrkpd
--

ALTER TABLE ONLY public.user_role
    ADD CONSTRAINT user_role_fk1 FOREIGN KEY (role_id) REFERENCES public.app_role(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: DATABASE db_sso_tegal; Type: ACL; Schema: -; Owner: postgres
--

GRANT CREATE,TEMPORARY ON DATABASE db_sso_tegal TO monevrkpd;


--
-- PostgreSQL database dump complete
--

